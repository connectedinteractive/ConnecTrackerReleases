//
//  macros_all.h
//  macros_blocks
//
//  Created by Alexey Belkevich on 7/22/14.
//  Copyright (c) 2014 okolodev. All rights reserved.
//

#import "macros_blocks.h"
#import "macros_extra.h"