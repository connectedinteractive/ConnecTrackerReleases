//
//  ConnectTrackerAttribution.h
//  Adjust
//
//  Created by Marcelo on 2020-09-24.
//

#import <Foundation/Foundation.h>
#import "ConnectTrackerCallbackData.h"

NS_ASSUME_NONNULL_BEGIN

@interface ConnectTrackerAttribution : ConnectTrackerCallbackData

@end

NS_ASSUME_NONNULL_END
