//
//  CI_StringUtils.h
//  ConnectSDK
//
//  Created by Marcelo Santos on 21/12/17.
//  Copyright © 2017 Connected Interactive. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CI_StringUtils : NSObject

+ (NSString *)getHexadecimal: (NSMutableData*) data;

@end
