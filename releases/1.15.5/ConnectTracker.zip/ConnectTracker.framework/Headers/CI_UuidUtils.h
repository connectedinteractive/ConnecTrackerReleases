//
//  CI_UuidUtils.h
//  ConnectSDK
//
//  Created by Marcelo on 2020-09-23.
//  Copyright © 2020 Connected Interactive. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CI_UuidUtils : NSObject

+(NSString*)getUUid;

@end

NS_ASSUME_NONNULL_END
