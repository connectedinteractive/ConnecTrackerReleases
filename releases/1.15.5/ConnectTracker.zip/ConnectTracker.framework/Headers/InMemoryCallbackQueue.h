//
//  InMemoryCallbackQueue.h
//  Adjust
//
//  Created by Marcelo on 2020-09-25.
//

#import <Foundation/Foundation.h>
#import "CallbackQueue.h"

NS_ASSUME_NONNULL_BEGIN

@interface InMemoryCallbackQueue : NSObject<CallbackQueue>

@end

NS_ASSUME_NONNULL_END
